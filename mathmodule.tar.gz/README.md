# mathmodule

A simple math evaluation module created by Olan.

## Usage

```python
from mathmodule import start

# Start interactive loop
start.startnow()

# One-time input
start.startonce()
```
