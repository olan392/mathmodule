#--------------------------
#| math module |
#-------------------------

#startcode:
print('mathmodule v1.0 hi from olan')
#libraries:
import math
#important vars:
PI = math.pi
E = math.e
#vars:
history = []
#other:
pass
#decorations:
pass
#classes:
class start:
    @staticmethod
    def startnow():
        global history, PI, E
        while True:
            expr = input('> ')
            if expr == 'showhistory':
                print('history:', *history)
                continue
            try:
                print(eval(expr))
                history.append(expr)
            except Exception:
                print('must be a math equation or "showhistory"')
    @staticmethod
    def startonce():
        expr = input('> ')
        if expr == 'showhistory':
            print('history:', *history)
            return
        try:
            print(eval(expr))
            history.append(expr)
        except Exception:
            print('must be a math equation or "showhistory"')
#functions:
pass
#endcode:
print('starting mathmodule v1.0...')
